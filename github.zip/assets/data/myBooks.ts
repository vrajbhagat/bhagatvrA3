import {BookInfo} from '../../app/bookInfo';
export const MYBOOKS: BookInfo[] = [
    {bname: 'Aurora Rising', bauthor: 'Amie Kaufman', bgenre: "Children's", byear: '07-05-2019', bpicture:"image1"},
    {bname: 'The October Man ', bauthor: 'Ben Aaronovitch', bgenre: "Fantasy", byear: '01-05-2019', bpicture:"image2"},
    {bname: 'The Paper Wasp', bauthor: 'Lauren Acampora', bgenre: "Fiction", byear: '01-06-2019', bpicture:"image3"},
    {bname: 'The Redemption of Time', bauthor: 'Baoshu', bgenre: "Horror", byear: '16-07-2019', bpicture:"image4"}
]